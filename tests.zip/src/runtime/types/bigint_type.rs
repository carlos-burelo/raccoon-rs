// use super::TypeHandler;
// use crate::error::RaccoonError;
// use crate::runtime::{RuntimeValue, StrValue};
// use crate::tokens::Position;
// use async_trait::async_trait;

// pub struct BigIntType;

// #[async_trait]
// impl TypeHandler for BigIntType {
//     fn type_name(&self) -> &str {
//         "bigint"
//     }

//     fn call_instance_method(
//         &self,
//         value: &mut RuntimeValue,
//         method: &str,
//         _args: Vec<RuntimeValue>,
//         position: Position,
//         file: Option<String>,
//     ) -> Result<RuntimeValue, RaccoonError> {
//         let bigint = match value {
//             RuntimeValue::BigInt(b) => &b.value,
//             _ => {
//                 return Err(RaccoonError::new(
//                     format!("Expected bigint, got {}", value.get_name()),
//                     position,
//                     file,
//                 ));
//             }
//         };

//         match method {
//             "toStr" => Ok(RuntimeValue::Str(StrValue::new(format!("{}n", bigint)))),
//             _ => Err(RaccoonError::new(
//                 format!("Method '{}' not found on bigint", method),
//                 position,
//                 file,
//             )),
//         }
//     }

//     fn call_static_method(
//         &self,
//         method: &str,
//         _args: Vec<RuntimeValue>,
//         position: Position,
//         file: Option<String>,
//     ) -> Result<RuntimeValue, RaccoonError> {
//         Err(RaccoonError::new(
//             format!("Static method '{}' not found on bigint type", method),
//             position,
//             file,
//         ))
//     }

//     fn has_instance_method(&self, method: &str) -> bool {
//         matches!(method, "toStr")
//     }

//     fn has_static_method(&self, _method: &str) -> bool {
//         false
//     }
// }
