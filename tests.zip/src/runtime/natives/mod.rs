pub mod array;
pub mod ffi;
pub mod http;
/// Native function modules
///
/// This module organizes native functions by category to keep the codebase modular
/// and prevent native_bridge.rs from growing indefinitely.
///
/// Each submodule provides functions to register its category of natives.
pub mod io;
pub mod json;
pub mod math;
pub mod output;
pub mod random;
pub mod string;
pub mod time;

use crate::runtime::values::NativeFunctionValue;
use std::collections::HashMap;

/// Helper struct to accumulate all native functions
pub struct NativeRegistry {
    pub functions: HashMap<String, NativeFunctionValue>,
    pub async_functions: HashMap<String, crate::runtime::values::NativeAsyncFunctionValue>,
}

impl NativeRegistry {
    pub fn new() -> Self {
        Self {
            functions: HashMap::new(),
            async_functions: HashMap::new(),
        }
    }

    /// Register all native functions from all modules
    pub fn register_all(&mut self) {
        output::register(&mut self.functions);
        time::register(&mut self.functions);
        random::register(&mut self.functions);
        json::register(&mut self.functions);
        string::register(&mut self.functions);
        array::register(&mut self.functions);
        math::register(&mut self.functions);
        ffi::register(&mut self.functions);
        http::register_async(&mut self.async_functions);

        // Create backward compatibility aliases for old naming convention
        self.create_aliases();
    }

    /// Create aliases for old naming convention (native_*) to new convention (native_*)
    fn create_aliases(&mut self) {
        // Array aliases
        if let Some(func) = self.functions.get("native_array_length").cloned() {
            self.functions.insert("native_length".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_push").cloned() {
            self.functions.insert("native_push".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_pop").cloned() {
            self.functions.insert("native_pop".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_shift").cloned() {
            self.functions.insert("native_shift".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_unshift").cloned() {
            self.functions.insert("native_unshift".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_slice").cloned() {
            self.functions.insert("native_slice".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_reverse").cloned() {
            self.functions.insert("native_reverse".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_array_sort").cloned() {
            self.functions.insert("native_sort".to_string(), func);
        }

        // String aliases
        if let Some(func) = self.functions.get("native_str_length").cloned() {
            self.functions.insert("native_length".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_upper").cloned() {
            self.functions.insert("native_upper".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_lower").cloned() {
            self.functions.insert("native_lower".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_trim").cloned() {
            self.functions.insert("native_trim".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_substring").cloned() {
            self.functions.insert("native_substring".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_char_at").cloned() {
            self.functions.insert("native_char_at".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_index_of").cloned() {
            self.functions.insert("native_index_of".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_replace").cloned() {
            self.functions.insert("native_replace".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_split").cloned() {
            self.functions.insert("native_split".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_starts_with").cloned() {
            self.functions
                .insert("native_starts_with".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_str_ends_with").cloned() {
            self.functions.insert("native_ends_with".to_string(), func);
        }

        // JSON aliases
        if let Some(func) = self.functions.get("native_json_parse").cloned() {
            self.functions.insert("native_parse".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_json_stringify").cloned() {
            self.functions.insert("native_stringify".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_json_stringify_pretty").cloned() {
            self.functions
                .insert("native_stringify_pretty".to_string(), func);
        }

        // Time aliases
        if let Some(func) = self.functions.get("native_time_now").cloned() {
            self.functions.insert("native_now".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_time_now_secs").cloned() {
            self.functions.insert("native_now_secs".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_time_sleep").cloned() {
            self.functions.insert("native_sleep".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_time_format").cloned() {
            self.functions.insert("native_format".to_string(), func);
        }

        // Random aliases
        if let Some(func) = self.functions.get("native_random").cloned() {
            self.functions.insert("native_random".to_string(), func);
        }

        // IO aliases
        if let Some(func) = self.functions.get("native_io_read_file").cloned() {
            self.functions.insert("native_read_file".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_write_file").cloned() {
            self.functions.insert("native_write_file".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_append_file").cloned() {
            self.functions
                .insert("native_append_file".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_file_exists").cloned() {
            self.functions
                .insert("native_file_exists".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_delete_file").cloned() {
            self.functions
                .insert("native_delete_file".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_read_dir").cloned() {
            self.functions.insert("native_read_dir".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_create_dir").cloned() {
            self.functions.insert("native_create_dir".to_string(), func);
        }
        if let Some(func) = self.functions.get("native_io_input").cloned() {
            self.functions.insert("native_input".to_string(), func);
        }
    }
}
